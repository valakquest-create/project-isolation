export { locationApi } from "./location.api";
