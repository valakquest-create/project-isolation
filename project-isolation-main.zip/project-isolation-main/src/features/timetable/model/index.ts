export { TimeTableProvider, useTimeTableContext } from "./context";
export type { ITimeTableContext } from "./context";
