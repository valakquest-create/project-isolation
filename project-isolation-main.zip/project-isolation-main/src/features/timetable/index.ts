export { useTimeTableContext, TimeTableProvider } from "./model";
export type { ITimeTableContext } from "./model";
