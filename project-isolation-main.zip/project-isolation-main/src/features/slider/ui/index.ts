export { Slider } from "./slider";
