export { CertificateCharacteristics } from "./characteristics";
