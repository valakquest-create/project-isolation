export const navigations = {
  quests: {
    text: "Квесты",
    id: "quests",
    href: "/#quests",
  },
  contacts: {
    text: "Контакты",
    id: "contacts",
    href: "#contacts",
  },
  // {
  //     text: 'Заказать праздник',
  //     id: 'Holiday',
  //     href: '/holiday'
  // },
  // {
  //     text: 'Выездные мероприятия',
  //     id: 'Holiday',
  //     href: '/holiday-2'
  // },
  certificate: {
    text: "Сертификаты",
    id: "certificate",
    href: "/certificate",
  },
  franchising: {
    text: "Франшиза",
    id: "franchising",
    href: "/franchising",
  },
};
