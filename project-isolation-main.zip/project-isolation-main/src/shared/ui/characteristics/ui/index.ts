export { Characteristics } from "./characteristics-list";
