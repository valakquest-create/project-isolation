export { Characteristics } from "./ui";
