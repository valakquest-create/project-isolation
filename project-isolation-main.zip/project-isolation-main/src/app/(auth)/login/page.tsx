import { SignInButton } from "@/features/auth";

export default async function LoginPage() {
  return <SignInButton />;
}
