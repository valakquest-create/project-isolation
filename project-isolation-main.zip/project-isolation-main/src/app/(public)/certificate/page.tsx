// eslint-disable-next-line import/no-internal-modules
import { CertificatePage } from "@/app-pages/certificates";

export default function Page() {
  return <CertificatePage />;
}
