// eslint-disable-next-line import/no-internal-modules
import MainPage from "@/app-pages/main";

export default function Home() {
  return <MainPage />;
}
