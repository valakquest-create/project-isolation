import { Confirmation } from "@/app-pages";

export default function Page() {
  return <Confirmation />;
}
