import { Franchising } from "@/app-pages/";

export default function Page() {
  return <Franchising />;
}
