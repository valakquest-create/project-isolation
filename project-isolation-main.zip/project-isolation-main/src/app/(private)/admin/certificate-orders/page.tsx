import { CertificateOrdersList } from "@/widgets/certificate-orders-list";

export default async function Page() {
  return <CertificateOrdersList />;
}
