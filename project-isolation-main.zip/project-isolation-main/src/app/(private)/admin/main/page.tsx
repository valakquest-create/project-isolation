// eslint-disable-next-line import/no-internal-modules
import AdminMain from "@/app-pages/admin-main";

export default function MainPage() {
  return <AdminMain />;
}
