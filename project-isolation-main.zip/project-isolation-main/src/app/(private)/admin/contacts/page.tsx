// eslint-disable-next-line import/no-internal-modules
import ContactsPage from "@/app-pages/contacts";

export default function Contacts() {
  return <ContactsPage />;
}
