import { HolidaysPage } from "@/app-pages/";

export default function Holidays() {
  return <HolidaysPage />;
}
