// eslint-disable-next-line import/no-internal-modules
import AdminQuests from "@/app-pages/admin-quests";

export default function Quests() {
  return <AdminQuests />;
}
