// eslint-disable-next-line import/no-internal-modules
import { AdminCertificates } from "@/app-pages/admin-certificates";

export default function Page() {
  return <AdminCertificates />;
}
