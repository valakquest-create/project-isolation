export { questPageRepository } from "./questPage.repository";
