export { questPageRepository } from "./api";
