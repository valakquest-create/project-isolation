export { mainPageRepository } from "./api";
