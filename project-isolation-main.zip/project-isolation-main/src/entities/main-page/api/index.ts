export { mainPageRepository } from "./main-page.repository";
