export { certificatesPageRepository } from "./api";
