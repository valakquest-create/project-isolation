export { certificatesPageRepository } from "./certificates-page.repository";
