export { ContactType } from "./types";
export type { Contact } from "./types";
