export { franchisingRepository } from "./franchising.repository";
export type {
  Franchising,
  CreateFranchisingCommand,
  UpdateFranchisingCommand,
} from "./types";
