-- CreateTable
CREATE TABLE "MainPage" (
    "id" SERIAL NOT NULL,
    "about" TEXT NOT NULL,

    CONSTRAINT "MainPage_pkey" PRIMARY KEY ("id")
);
