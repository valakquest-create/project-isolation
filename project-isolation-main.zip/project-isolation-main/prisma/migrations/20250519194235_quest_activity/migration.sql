-- AlterTable
ALTER TABLE "Quest" ADD COLUMN     "isActive" BOOLEAN NOT NULL DEFAULT true;
