-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "name" VARCHAR(255),
ADD COLUMN     "phone" VARCHAR(255);
