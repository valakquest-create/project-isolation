-- AlterTable
ALTER TABLE "CertificateOrder" ALTER COLUMN "updatedAt" DROP DEFAULT;
